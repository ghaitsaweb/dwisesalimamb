# -*- coding: utf-8 -*-
{
    'name': "DSD - Custom Proyek SBI",

    'summary': """
        Task Minor Untuk Proyek SBI dijadikan satu di modul ini
       """,

    'description': """
        1. menambah field pengirim dan penerima pada printout delivery slip
        2. disable printout rfq
    """,

    'author': "PT. Dwisesa Solusi Digitalindo",
    'website': "http://www.dwisesa.id",

    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','stock','purchase'],

    # always loaded
    'data': [
        'report/report_deliveryslip.xml',
        'report/purchase_reports.xml',
        'views/purchase_views.xml',
    ]
}
