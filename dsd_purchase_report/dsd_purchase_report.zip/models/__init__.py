# -*- coding: utf-8 -*-

from . import res_company
from . import base_document_layout
